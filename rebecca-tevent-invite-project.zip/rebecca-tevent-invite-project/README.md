# Rebecca T - Event Invite Project

A Pen created on CodePen.

Original URL: [https://codepen.io/rebecca-t-01/pen/GgRVypO](https://codepen.io/rebecca-t-01/pen/GgRVypO).

